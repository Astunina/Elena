﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;

namespace Lab2
{

    public class Input
    {
        public int K { get; set; }
        public decimal[] Sums { get; set; }
        public int[] Muls { get; set; }

        public Input()
        {
        }

        public Input(int k, int[] muls, decimal[] sums)
        {
            K = k;
            Sums = sums;
            Muls = muls;
        }

        public override string ToString()
        {
            return string.Format("K: {0}\nSums: {1}\n Muls: {2}", K, string.Join(", ", Sums), string.Join(", ", Muls));
        }
    }

    public class Output
    {
        public decimal SumResult { get; set; }
        public int MulResult { get; set; }
        public decimal[] SortedInputs { get; set; }

        public Output()
        {
        }

        public Output(decimal sumResult, int mulResult, decimal[] sortedInputs)
        {
            SumResult = sumResult;
            MulResult = mulResult;
            SortedInputs = sortedInputs;
        }

        public Output(Input input)
        {
            SumResult = input.Sums.Sum();
            SumResult *= input.K;

            MulResult = input.Muls[0];
            for (int i = 1; i < input.Muls.Length; i++)
            {
                MulResult *= input.Muls[i];
            }

            List<decimal> temp = new List<decimal>();
            foreach (int i in input.Muls)
                temp.Add(i);
            temp.AddRange(input.Sums);
            SortedInputs = temp.OrderBy(x => x).ToArray();
        }

        public override string ToString()
        {
            return string.Format("SumResult: {0}\nMulResult: {1}\nSortedInputs: {2}", SumResult, MulResult, string.Join(", ", SortedInputs));
        }

        public override bool Equals(object obj)
        {
            Output output = (Output)obj;
            if (output == null)
                return false;

            if (output.SumResult != SumResult)
                return false;

            if (output.MulResult != MulResult)
                return false;

            return SortedInputs.SequenceEqual(output.SortedInputs);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }

    class Program
    {
        static HttpClient client = new HttpClient();
        static string url = "http://127.0.0.1:8000/";

        static async Task Run()
        {
            client.BaseAddress = new Uri(url);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            try
            {
                HttpResponseMessage msg;
                Output answer;

                //Ping
                Console.WriteLine("Pinging the server...");
                msg = await client.GetAsync("Ping");
                if (msg.IsSuccessStatusCode)
                {
                    string x = await msg.Content.ReadAsStringAsync();
                    Console.WriteLine(x);
                }
                else
                {
                    return;
                }
                Console.WriteLine();

                //Get Input Data
                Console.WriteLine("Get input data...");
                msg = await client.GetAsync("GetInputData");
                if (msg.IsSuccessStatusCode)
                {
                    string x = await msg.Content.ReadAsStringAsync();
                    Input input = JsonSerializer.Deserialize<Input>(x);
                    answer = new Output(input);
                    Console.WriteLine(input.ToString());
                }
                else
                {
                    return;
                }
                Console.WriteLine();

                //WriteAnswer
                Console.WriteLine("WriteAnswer...");
                StringContent stringContent = new StringContent(JsonSerializer.Serialize(answer), Encoding.UTF8);
                msg = await client.PutAsync("WriteAnswer", stringContent);
                if (msg.IsSuccessStatusCode)
                {
                    string x = await msg.Content.ReadAsStringAsync();
                    Console.WriteLine(x);
                }
                else
                {
                    return;
                }
                Console.WriteLine();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            Console.ReadLine();
        }

        static void Main(string[] args)
        {
            Run().GetAwaiter().GetResult();
        }
    }
}

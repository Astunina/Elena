﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Xml;
using System.Xml.Serialization;

namespace Lab1
{
    public class Input
    {
        public int K { get; set; }
        public decimal[] Sums { get; set; }
        public int[] Muls { get; set; } 
    }

    public class Output
    {
        public decimal SumResult { get; set; }
        public int MulResult { get; set; }
        public decimal[] SortedInputs { get; set; }
    }

    class Program
    {
        static Output InputManipulation(Input input)
        {
            decimal sumResult = 0;
            for (int i = 0; i < input.Sums.Length; i++)
                sumResult += input.Sums[i];
            sumResult *= input.K;

            int mulResult = input.Muls[0];
            for (int i = 1; i < input.Muls.Length; i++)
                mulResult *= input.Muls[i];

            List<decimal> sortedInputs = new List<decimal>();
            sortedInputs.AddRange(input.Sums);
            for (int i = 0; i < input.Muls.Length; i++)
                sortedInputs.Add((decimal)input.Muls[i]);
            sortedInputs.Sort();

            Output result = new Output();
            result.SumResult = sumResult;
            result.MulResult = mulResult;
            result.SortedInputs = sortedInputs.ToArray();
            return result;
        }

        static void Main(string[] args)
        {
            int c = -1;

            while (c < 0 || c > 3)
            {
                Console.WriteLine("Выберите действие: 1 - чтение json, 2 - чтение xml, 3 - выход.");
                c = Convert.ToInt32(Console.ReadLine());
            }

            if (c == 3)
                return;

            string inputString = string.Empty;
            Input input = new Input();
            Output output = new Output();
            if (c == 1)
            {
                #region Read
                if (File.Exists("input.json"))
                {
                    inputString = File.ReadAllText("input.json");
                }
                else
                {
                    Console.WriteLine("Файл input.json не найден!");
                    Console.ReadLine();
                    return;
                }

                if (!string.IsNullOrEmpty(inputString))
                {
                    try
                    {
                        input = JsonSerializer.Deserialize<Input>(inputString);
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);
                        Console.ReadLine();
                        return;
                    }
                }
                else
                {
                    Console.WriteLine("Файл input.json пуст!");
                    Console.ReadLine();
                    return;
                }
                #endregion

                #region Manipulation
                output = InputManipulation(input);
                #endregion

                #region Write
                try
                {
                    string outputString = JsonSerializer.Serialize(output);
                    File.WriteAllText("output.json", outputString);
                }
                catch(Exception e)
                {
                    Console.WriteLine(e.Message);
                    Console.ReadLine();
                    return;
                }
                finally
                {
                    Console.WriteLine("Файл output.json успешно записан!");
                    Console.ReadLine();
                }
                #endregion
            }
            else
            {
                #region Read
                if (File.Exists("input.xml"))
                {
                    inputString = File.ReadAllText("input.xml");
                }
                else
                {
                    Console.WriteLine("Файл input.xml не найден!");
                    Console.ReadLine();
                    return;
                }

                if (!string.IsNullOrEmpty(inputString))
                {
                    try
                    {
                        XmlSerializer serializer = new XmlSerializer(typeof(Input));

                        using (Stream reader = new FileStream("input.xml", FileMode.Open))
                        {
                            input = (Input)serializer.Deserialize(reader);
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);
                        Console.ReadLine();
                        return;
                    }
                }
                else
                {
                    Console.WriteLine("Файл input.xml пуст!");
                    Console.ReadLine();
                    return;
                }
                #endregion

                #region Manipulation
                output = InputManipulation(input);
                #endregion

                #region Write
                try
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(Output));
                    Stream fs = new FileStream("output.xml", FileMode.Create);
                    XmlWriter writer = new XmlTextWriter(fs, System.Text.Encoding.Unicode);
                    serializer.Serialize(writer, output);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    Console.ReadLine();
                    return;
                }
                finally
                {
                    Console.WriteLine("Файл output.xml успешно записан!");
                    Console.ReadLine();
                }
                #endregion
            }

            #region Print
            Console.WriteLine("Результат.");
            Console.WriteLine("SumResult: " + output.SumResult);
            Console.WriteLine("MulResult: " + output.MulResult);
            Console.Write("SortedInputs: ");
            for (int i = 0; i < output.SortedInputs.Length; i++)
                Console.Write(output.SortedInputs[i] + " ");
            Console.ReadLine();
            return;
            #endregion
        }
    }
}

﻿using System;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Net;
using System.Threading.Tasks;
using System.Linq;
using System.Collections.Generic;

namespace Lab3
{

    public class Input
    {
        public int K { get; set; }
        public decimal[] Sums { get; set; }
        public int[] Muls { get; set; }

        public Input()
        {
        }

        public Input(int k, int[] muls, decimal[] sums)
        {
            K = k;
            Sums = sums;
            Muls = muls;
        }

        public override string ToString()
        {
            return string.Format("K: {0}\nSums: {1}\n Muls: {2}", K, string.Join(", ", Sums), string.Join(", ", Muls));
        }
    }

    public class Output
    {
        public decimal SumResult { get; set; }
        public int MulResult { get; set; }
        public decimal[] SortedInputs { get; set; }

        public Output()
        {
        }

        public Output(decimal sumResult, int mulResult, decimal[] sortedInputs)
        {
            SumResult = sumResult;
            MulResult = mulResult;
            SortedInputs = sortedInputs;
        }

        public Output(Input input)
        {
            SumResult = input.Sums.Sum();
            SumResult *= input.K;

            MulResult = input.Muls[0];
            for (int i = 1; i < input.Muls.Length; i++)
            {
                MulResult *= input.Muls[i];
            }

            List<decimal> temp = new List<decimal>();
            foreach (int i in input.Muls)
                temp.Add(i);
            temp.AddRange(input.Sums);
            SortedInputs = temp.OrderBy(x => x).ToArray();
        }

        public override string ToString()
        {
            return string.Format("SumResult: {0}\nMulResult: {1}\nSortedInputs: {2}", SumResult, MulResult, string.Join(", ", SortedInputs));
        }

        public override bool Equals(object obj)
        {
            Output output = (Output)obj;
            if (output == null)
                return false;

            if (output.SumResult != SumResult)
                return false;

            if (output.MulResult != MulResult)
                return false;

            return SortedInputs.SequenceEqual(output.SortedInputs);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }

    class Program
    {
        public static HttpListener listener;
        public static string url = "http://127.0.0.1:8000/";
        public static string pageData =
            "<DOCTYPE>" +
            "<html>" +
            "   <head>" +
            "       <title>Lab3</title>" +
            "   </head>" +
            "   <body>" +
            "   </body>" +
            "</html>";

        private static Output answer;
        private static Input inputData = new Input(10, new int[] { 1, 4 }, new decimal[] { 1.01M, 2.02M });
        private static Output answerData = new Output(30.30M, 4, new decimal[] { 1M, 1.01M, 2.02M, 4M });

        public static async Task HandleIncomingConnections()
        {
            bool run = true;

            while(run)
            {
                byte[] data = new byte[0];
                HttpListenerContext ctx = await listener.GetContextAsync();

                HttpListenerRequest req = ctx.Request;
                HttpListenerResponse res = ctx.Response;

                Console.Clear();
                Console.WriteLine(req.Url.ToString());
                Console.WriteLine(req.HttpMethod);
                Console.WriteLine(req.UserHostName);
                Console.WriteLine(req.UserAgent);
                Console.WriteLine();

                if (req.HttpMethod == "GET")
                {
                    if (req.Url.AbsolutePath == "/Ping")
                    {
                        Console.WriteLine("Ping");
                        data = Encoding.UTF8.GetBytes(HttpStatusCode.OK.ToString());
                    }
                    else if (req.Url.AbsolutePath == "/GetInputData")
                    {
                        Console.WriteLine("Get Input Data");
                        data = JsonSerializer.SerializeToUtf8Bytes(inputData);
                        Console.WriteLine(inputData.ToString());
                    }
                    else if (req.Url.AbsolutePath == "/GetAnswer")
                    {
                        Console.WriteLine("Get Answer");
                        if (answer != null)
                        {
                            Console.WriteLine(answer.ToString());
                            data = JsonSerializer.SerializeToUtf8Bytes(answer);
                        }
                        else
                        {
                            Console.WriteLine("Answer is null");
                            data = Encoding.UTF8.GetBytes("Answer is null. Send InputData first!");
                        }
                    }
                }

                if (req.HttpMethod == "PUT")
                {
                    if (req.Url.AbsolutePath == "/PostInputData")
                    {
                        Console.WriteLine("InputData");
                        if (!req.HasEntityBody)
                        {
                            Console.WriteLine("Input data is empty!");
                            data = Encoding.UTF8.GetBytes("Input data is empty!");
                        }
                        else
                        {
                            Console.WriteLine("Reading input data...");
                            StreamReader reader = new StreamReader(req.InputStream, Encoding.UTF8);
                            string inputData = reader.ReadToEnd();
                            Input input = JsonSerializer.Deserialize<Input>(inputData);
                            answer = new Output(input);
                            Console.WriteLine(input.ToString());
                            data = Encoding.UTF8.GetBytes(HttpStatusCode.Accepted.ToString());
                        }
                    }
                    else if (req.Url.AbsolutePath == "/WriteAnswer")
                    {
                        Console.WriteLine("WriteAnswer");
                        if (!req.HasEntityBody)
                        {
                            Console.WriteLine("Answer is empty!");
                            data = Encoding.UTF8.GetBytes("Answer is empty!");
                        }
                        else
                        {
                            Console.WriteLine("Reading answer...");
                            StreamReader reader = new StreamReader(req.InputStream, Encoding.UTF8);
                            string inputData = reader.ReadToEnd();
                            Output inputAnswer = JsonSerializer.Deserialize<Output>(inputData);
                            Console.WriteLine(inputAnswer.ToString());
                            bool right = inputAnswer.Equals(answerData);
                            data = Encoding.UTF8.GetBytes(right ? "Answer is right" : "Answer is wrong");
                        }
                    }
                }

                if (req.HttpMethod == "POST")
                {
                    if (req.Url.AbsolutePath == "/Stop")
                    {
                        Console.WriteLine("Shutdown requested");
                        run = false;
                    }
                }

                res.ContentType = "text/html";
                res.ContentEncoding = Encoding.UTF8;
                res.ContentLength64 = data.LongLength;

                await res.OutputStream.WriteAsync(data, 0, data.Length);
                res.Close();
            }
        }

        static void Main(string[] args)
        {
            listener = new HttpListener();
            listener.Prefixes.Add(url);
            listener.Start();
            Console.WriteLine("Listening for connections on {0}", url);

            Task listenTask = HandleIncomingConnections();
            listenTask.GetAwaiter().GetResult();

            listener.Close();
        }
    }
}
